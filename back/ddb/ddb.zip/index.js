const AWS = require("aws-sdk");
const ddb = new AWS.DynamoDB.DocumentClient({ region: "eu-west-1" });
const jsonFile = require("./dictionary.json");

module.exports.handler = () => {
  const addItems2DDB = async () => {
    for (let i = 75005; i < jsonFile.length; i++) {
      const params = {
        TableName: "DictionaryEnglish",
        Item: jsonFile[i],
      };
      const logger = ddb
        .put(params, (err, data) => {
          if (err) return err;
          return data;
        })
        .promise();
      console.log(logger);
    }
    return "end!"
  };
  addItems2DDB();
}
